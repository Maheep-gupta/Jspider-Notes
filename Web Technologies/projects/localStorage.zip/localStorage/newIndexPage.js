if (localStorage.getItem('theme') === 'dark') {
    document.body.style.backgroundColor = '#212121'
}
else {
    document.body.style.backgroundColor = '#fff'
}